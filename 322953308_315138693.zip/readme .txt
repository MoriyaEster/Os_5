Moriya Ester Ohayon 322953308
Ofek Kats 315138693

linux 22.04

use the command: make all 
	usage: st_pipeline <N> <(optional)RAND>

Files added-
	makefile
	st_pipeline.c
	screenshot

with the command make clean the O files be deleted.